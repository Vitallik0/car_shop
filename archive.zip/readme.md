# 🚗 Автосалон Premium — Система управления продажами

MVP веб-приложения для управления автосалоном: каталог автомобилей, бронирование тест-драйвов, оформление продаж и аналитика.

**Стек:** Django 4.x + SQLite + Bootstrap 5

---

## 📋 Требования

- Python 3.8 или выше
- pip (менеджер пакетов Python)

---

## 🚀 Быстрый запуск

```bash
# 1. Скачайте проект (если используется Git)
git clone <ссылка-на-репозиторий>
cd dealership_system

# 2. Создайте виртуальное окружение
python -m venv venv

# 3. Активируйте виртуальное окружение
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# 4. Установите зависимости
pip install django

# 5. Примените миграции базы данных
python manage.py migrate

# 6. Загрузите тестовые данные 
python manage.py loaddata fixtures/initial_data.json

# 7. Создайте учётную запись администратора/менеджера
python manage.py createsuperuser
# Введите логин, email (можно пропустить), пароль

# 8. Запуск проекта
python manage.py runserver 